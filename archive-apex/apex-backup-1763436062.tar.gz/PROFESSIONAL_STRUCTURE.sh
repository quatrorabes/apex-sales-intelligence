#!/bin/bash

# Create professional monorepo structure
mkdir -p apex/{apps,packages,infrastructure,docs,scripts,.github/workflows}

# Reorganize
mv apex-backend apps/backend
mv apex-frontend apps/frontend
mkdir -p apps/dashboard-new
cp -r ~/projects/sales-fox/dashboard-new/* apps/dashboard-new/

# Shared code
mkdir -p packages/api-client
cp shared-api-client/apex-client.js packages/api-client/

# Infrastructure
mkdir -p infrastructure/{docker,kubernetes,scripts}

# Documentation
touch docs/{ARCHITECTURE.md,API.md,DEPLOYMENT.md,CONTRIBUTING.md}

# CI/CD
touch .github/workflows/{test.yml,build.yml,deploy.yml}

# Root config
cat > package.json << 'PKGJSON'
{
  "name": "apex-platform",
  "version": "1.0.0",
  "private": true,
  "workspaces": [
    "apps/*",
    "packages/*"
  ]
}
PKGJSON

echo "✅ Professional structure created!"
