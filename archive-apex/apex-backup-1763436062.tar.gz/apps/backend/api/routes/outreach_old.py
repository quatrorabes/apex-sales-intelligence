from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional, List

router = APIRouter(prefix="/api/v1/outreach", tags=["Outreach"])

# ═══════════════════════════════════════════════════════════════════════════
# EMAIL GENERATION
# ═══════════════════════════════════════════════════════════════════════════

@router.post("/contacts/{contact_id}/emails")
async def generate_emails(contact_id: int, count: int = 3):
    """Generate high-quality outreach emails"""
    try:
        from intelligence.outreach.generators.email_generator import EmailGenerator
        generator = EmailGenerator()
        emails = generator.generate_quality_emails(contact_id, count)
        return {
            "status": "success",
            "contact_id": contact_id,
            "emails": emails
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/contacts/{contact_id}/call-scripts")
async def generate_call_scripts(contact_id: int, script_type: str = "intro"):
    """Generate call scripts and talking points"""
    try:
        from intelligence.outreach.generators.call_script_generator import CallScriptGenerator
        generator = CallScriptGenerator()
        scripts = generator.generate_scripts(contact_id, script_type)
        return {
            "status": "success",
            "contact_id": contact_id,
            "scripts": scripts
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/contacts/{contact_id}/call-assistance")
async def get_call_assistance(contact_id: int):
    """Get AI call assistance and real-time tips"""
    try:
        from intelligence.outreach.generators.call_assistant import CallAssistant
        assistant = CallAssistant()
        guidance = assistant.get_call_guidance(contact_id)
        return {
            "status": "success",
            "contact_id": contact_id,
            "guidance": guidance
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# ═══════════════════════════════════════════════════════════════════════════
# RELATIONSHIP INTELLIGENCE
# ═══════════════════════════════════════════════════════════════════════════

@router.get("/contacts/{contact_id}/relationship-intelligence")
async def get_relationship_intelligence(contact_id: int):
    """Deep relationship and context analysis"""
    try:
        from intelligence.outreach.intelligence.relationship_intelligence import RelationshipIntelligence
        system = RelationshipIntelligence()
        intelligence = system.analyze_relationship(contact_id)
        return {
            "status": "success",
            "contact_id": contact_id,
            "intelligence": intelligence
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/contacts/{contact_id}/vertical-intelligence")
async def get_vertical_intelligence(contact_id: int):
    """Vertical-agnostic industry/vertical insights"""
    try:
        from intelligence.outreach.intelligence.vertical_intelligence import VerticalIntelligence
        system = VerticalIntelligence()
        intelligence = system.analyze_vertical(contact_id)
        return {
            "status": "success",
            "contact_id": contact_id,
            "intelligence": intelligence
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/contacts/{contact_id}/learning-recommendations")
async def get_learning_recommendations(contact_id: int):
    """Adaptive learning from past interactions"""
    try:
        from intelligence.outreach.intelligence.adaptive_learning import AdaptiveLearning
        engine = AdaptiveLearning()
        recommendations = engine.get_recommendations(contact_id)
        return {
            "status": "success",
            "contact_id": contact_id,
            "recommendations": recommendations
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# ═══════════════════════════════════════════════════════════════════════════
# ANALYTICS & REPORTING
# ═══════════════════════════════════════════════════════════════════════════

@router.get("/contacts/{contact_id}/conversion-analysis")
async def get_conversion_analysis(contact_id: int):
    """Conversion likelihood and tracking"""
    try:
        from intelligence.outreach.analytics.conversion_analytics import ConversionAnalytics
        analytics = ConversionAnalytics()
        analysis = analytics.analyze_conversion(contact_id)
        return {
            "status": "success",
            "contact_id": contact_id,
            "analysis": analysis
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/contacts/{contact_id}/outreach-analytics")
async def get_outreach_analytics(contact_id: int):
    """Complete outreach analytics and metrics"""
    try:
        from intelligence.outreach.analytics.analytics_engine import AnalyticsEngine
        engine = AnalyticsEngine()
        analytics = engine.get_outreach_analytics(contact_id)
        return {
            "status": "success",
            "contact_id": contact_id,
            "analytics": analytics
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/contacts/{contact_id}/deal-success-prediction")
async def predict_deal_success(contact_id: int):
    """ML-based deal success prediction"""
    try:
        from intelligence.outreach.analytics.ml_predictor import MLPredictor
        predictor = MLPredictor()
        prediction = predictor.predict_deal_success(contact_id)
        return {
            "status": "success",
            "contact_id": contact_id,
            "prediction": prediction
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# ═══════════════════════════════════════════════════════════════════════════
# ENRICHMENT & SETUP
# ═══════════════════════════════════════════════════════════════════════════

@router.post("/contacts/{contact_id}/quick-enrich")
async def quick_enrich_contact(contact_id: int):
    """Quick production enrichment"""
    try:
        from intelligence.outreach.utils.quick_enrichment import QuickEnrichment
        enricher = QuickEnrichment()
        enriched = enricher.enrich(contact_id)
        return {
            "status": "success",
            "contact_id": contact_id,
            "data": enriched
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/companies/setup-business-profile")
async def setup_business_profile(company_id: int):
    """Setup and configure business profile"""
    try:
        from intelligence.outreach.utils.business_profile import BusinessProfileSetup
        setup = BusinessProfileSetup()
        profile = setup.setup_profile(company_id)
        return {
            "status": "success",
            "company_id": company_id,
            "profile": profile
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
