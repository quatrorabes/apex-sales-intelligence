#!/usr/bin/env python3

# backend/api/routes/enrichment.py
from fastapi import APIRouter, HTTPException, BackgroundTasks
from backend.services.perplexity_enrichment import PerplexityEnrichmentService
from backend.models.database import Contact, SessionLocal

router = APIRouter()
enrichment_service = PerplexityEnrichmentService()

@router.post("/api/contacts/{contact_id}/enrich")
async def enrich_contact(
	contact_id: str,
	background_tasks: BackgroundTasks
):
	"""
	Trigger deep enrichment for a contact
	"""
	
	# Get contact from database
	db = SessionLocal()
	contact = db.query(Contact).filter(Contact.id == contact_id).first()
	
	if not contact:
		raise HTTPException(status_code=404, detail="Contact not found")
		
	# Run enrichment in background
	background_tasks.add_task(
		perform_enrichment,
		contact_id=contact_id
	)

	return {
		"status": "enrichment_started",
		"contact_id": contact_id,
		"message": "Enrichment running in background"
	}

async def perform_enrichment(contact_id: str):
	"""
	Background task to perform enrichment
	"""
	db = SessionLocal()
	contact = db.query(Contact).filter(Contact.id == contact_id).first()
	
	# Convert to dict for enrichment
	contact_dict = {
		"id": contact.id,
		"name": f"{contact.first_name} {contact.last_name}",
		"company": contact.company,
		"title": contact.title,
		"linkedin_url": contact.linkedin_url
	}
	
	# Perform enrichment
	enrichment_result = await enrichment_service.enrich_contact(contact_dict)
	
	# Save enrichment results
	contact.enrichment_data = enrichment_result['enrichment']
	contact.perplexity_data = enrichment_result
	contact.lead_score = enrichment_result['scoring']['total']
	contact.last_enriched = datetime.utcnow()
	
	db.commit()
	db.close()
	