#!/bin/bash

cd ~/projects/apex

# Create folders
mkdir -p apex-backend/intelligence/engines
mkdir -p apex-backend/intelligence/advanced
mkdir -p apex-backend/intelligence/outreach/generators
mkdir -p apex-backend/intelligence/outreach/intelligence
mkdir -p apex-backend/intelligence/outreach/analytics
mkdir -p apex-backend/intelligence/outreach/utils

# Create __init__.py files
touch apex-backend/intelligence/__init__.py
touch apex-backend/intelligence/engines/__init__.py
touch apex-backend/intelligence/advanced/__init__.py
touch apex-backend/intelligence/outreach/__init__.py
touch apex-backend/intelligence/outreach/generators/__init__.py
touch apex-backend/intelligence/outreach/intelligence/__init__.py
touch apex-backend/intelligence/outreach/analytics/__init__.py
touch apex-backend/intelligence/outreach/utils/__init__.py

# Move files
mv "persona_classifier_cre_sba.py" apex-backend/intelligence/engines/ 2>/dev/null
mv "profile_enrichment_engine.py" apex-backend/intelligence/engines/ 2>/dev/null
mv "linkedin_monitoring_integration.py" apex-backend/intelligence/engines/ 2>/dev/null
mv "method_reference.py" apex-backend/intelligence/engines/ 2>/dev/null
mv "call_assistant copy.py" apex-backend/intelligence/outreach/generators/call_assistant.py 2>/dev/null
mv "call_script_generator copy.py" apex-backend/intelligence/outreach/generators/call_script_generator.py 2>/dev/null
mv "adaptive_learning_engine copy.py" apex-backend/intelligence/outreach/intelligence/adaptive_learning.py 2>/dev/null
mv "relationship_intelligence_system copy.py" apex-backend/intelligence/outreach/intelligence/relationship_intelligence.py 2>/dev/null
mv "vertical_agnostic_intelligence copy.py" apex-backend/intelligence/outreach/intelligence/vertical_intelligence.py 2>/dev/null
mv "analytics_engine copy.py" apex-backend/intelligence/outreach/analytics/analytics_engine.py 2>/dev/null
mv "conversion_report copy.py" apex-backend/intelligence/outreach/analytics/conversion_analytics.py 2>/dev/null
mv "ML-deal-success-predictor copy.py" apex-backend/intelligence/outreach/analytics/ml_predictor.py 2>/dev/null
mv "quick_enrichment_for_production copy.py" apex-backend/intelligence/outreach/utils/quick_enrichment.py 2>/dev/null
mv "setup_business_profile copy.py" apex-backend/intelligence/outreach/utils/business_profile.py 2>/dev/null

echo "✅ All files moved and organized!"
